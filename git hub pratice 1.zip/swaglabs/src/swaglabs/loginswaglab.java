package swaglabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
	
public class loginswaglab {

	public static void main(String[] args) {
		 // Set the path of the ChromeDriver executable
        System.getProperty(" C:\\Users\\DELL\\Downloads\\geckodriver-v0.34.0-win32\\chromedriver-mac-x64");

        // Initialize a new instance of the Chrome driver
        WebDriver driver = new ChromeDriver();

        // Open the Swag Labs website
        driver.get("https://www.saucedemo.com/");

        // Login to Swag Labs
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("standard_user");

        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("secret_sauce");

        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Verify login by checking for an element on the next page
        WebElement inventoryContainer = driver.findElement(By.id("inventory_container"));
        if (inventoryContainer.isDisplayed()) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Login failed!");
        }

        // Close the browser
        driver.quit();
    

}

}
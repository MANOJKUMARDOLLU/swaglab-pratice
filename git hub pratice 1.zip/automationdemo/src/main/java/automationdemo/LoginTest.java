package automationdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginTest {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        try {
            // Set the path to the ChromeDriver executable
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\geckodriver-v0.34.0-win32\\chromedriver.exe");

            // Initialize the ChromeDriver
            driver = new ChromeDriver();

            // Navigate to the Ultimate QA login page
            driver.get("https://ultimateqa.com/login");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Setup failed: " + e.getMessage());
        }
    }

    @Test
    public void testValidLogin() {
        try {
            // Locate the username, password fields, and login button
            WebElement username = driver.findElement(By.id("user[email]"));
            WebElement password = driver.findElement(By.id("user[password]"));
            WebElement loginButton = driver.findElement(By.name("commit"));

            // Perform login actions
            username.sendKeys("validUser");
            password.sendKeys("validPassword");
            loginButton.click();	

            // Check if the dashboard element is displayed
            WebElement dashboard = driver.findElement(By.id("dashboard"));
            Assert.assertTrue(dashboard.isDisplayed(), "Login failed or dashboard is not displayed.");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Test failed: " + e.getMessage());
            
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        
        }
        
    }
}
